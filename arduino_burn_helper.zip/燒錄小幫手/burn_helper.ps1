﻿# 燒錄小幫手
# 讓「音符視覺化」網頁把程式碼送過來，用 Arduino IDE 內附的 arduino-cli 編譯並燒錄到 Arduino Nano。
# 只接受本機（localhost）連線，而且只接受下面列出的網站。
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

$Port = 8766
$AllowedOrigins = @('https://fbkstj.github.io', 'http://127.0.0.1:8765', 'http://localhost:8765')
$Fqbn = 'arduino:avr:nano:cpu=atmega328'
$FqbnOld = 'arduino:avr:nano:cpu=atmega328old'
$HelperVersion = '1'
$SketchDir = Join-Path $env:TEMP 'arduino_burn_helper\student_sketch'
$SketchFile = Join-Path $SketchDir 'student_sketch.ino'

function Find-Cli {
  $cands = @(
    "$env:ProgramFiles\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe",
    "$env:LOCALAPPDATA\Programs\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe",
    "${env:ProgramFiles(x86)}\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe"
  )
  foreach ($c in $cands) { if ($c -and (Test-Path -LiteralPath $c)) { return $c } }
  $cmd = Get-Command arduino-cli -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return $null
}

# arduino-cli 輸出 UTF-8，但它轉出的 avrdude 訊息是系統編碼（繁中 Windows = Big5）：逐行判斷
$Utf8Strict = New-Object Text.UTF8Encoding($false, $true)
function Decode-Mixed([byte[]]$Bytes) {
  $sb = New-Object Text.StringBuilder
  $start = 0
  $n = $Bytes.Length
  while ($start -lt $n) {
    $i = [Array]::IndexOf($Bytes, [byte]10, $start)
    $end = if ($i -lt 0) { $n } else { $i + 1 }
    $len = $end - $start
    try { [void]$sb.Append($Utf8Strict.GetString($Bytes, $start, $len)) }
    catch { [void]$sb.Append([Text.Encoding]::Default.GetString($Bytes, $start, $len)) }
    $start = $end
  }
  return $sb.ToString()
}

function Invoke-Cli([string[]]$CliArgs, [int]$TimeoutMs = 180000) {
  $psi = New-Object Diagnostics.ProcessStartInfo
  $psi.FileName = $script:Cli
  $psi.Arguments = ($CliArgs | ForEach-Object { '"' + $_ + '"' }) -join ' '
  $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.CreateNoWindow = $true
  $p = [Diagnostics.Process]::Start($psi)
  $outMs = New-Object IO.MemoryStream
  $errMs = New-Object IO.MemoryStream
  $outTask = $p.StandardOutput.BaseStream.CopyToAsync($outMs)
  $errTask = $p.StandardError.BaseStream.CopyToAsync($errMs)
  if (-not $p.WaitForExit($TimeoutMs)) {
    # 連同 avrdude 子程式一起結束，否則它會一直占著 COM 埠
    try { & taskkill.exe /T /F /PID $p.Id 2>$null | Out-Null } catch {}
    try { $p.Kill() } catch {}
    return @{ code = -1; out = ''; err = 'TIMEOUT：執行太久沒有回應，已中止' }
  }
  $p.WaitForExit()
  try { $outTask.Wait(5000) | Out-Null; $errTask.Wait(5000) | Out-Null } catch {}
  return @{ code = $p.ExitCode; out = (Decode-Mixed $outMs.ToArray()); err = (Decode-Mixed $errMs.ToArray()) }
}

function Get-Ports {
  $list = @()
  $r = Invoke-Cli @('board', 'list', '--format', 'json') 30000
  try {
    $j = $r.out | ConvertFrom-Json
    $items = if ($j.detected_ports) { $j.detected_ports } else { $j }
    foreach ($d in $items) {
      $pt = $d.port
      if (-not $pt -or $pt.protocol -ne 'serial') { continue }
      $vid = "$($pt.properties.vid)"
      $list += [pscustomobject]@{ address = $pt.address; label = "$($pt.protocol_label)"; ch340 = ($vid -eq '0x1A86') }
    }
  } catch {}
  return ,$list
}

function Add-Cors($ctx) {
  $origin = $ctx.Request.Headers['Origin']
  if ($origin -and ($AllowedOrigins -contains $origin)) {
    $ctx.Response.AddHeader('Access-Control-Allow-Origin', $origin)
    $ctx.Response.AddHeader('Vary', 'Origin')
  }
}

function Send-Json($ctx, [int]$Status, $Obj) {
  $res = $ctx.Response
  Add-Cors $ctx
  $res.StatusCode = $Status
  $res.ContentType = 'application/json; charset=utf-8'
  $bytes = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $Obj -Depth 5 -Compress))
  $res.ContentLength64 = $bytes.Length
  $res.OutputStream.Write($bytes, 0, $bytes.Length)
  $res.OutputStream.Close()
}

function Tail-Log([string]$s, [int]$max = 8000) {
  if ($s.Length -le $max) { return $s }
  return '……（前面省略）' + $s.Substring($s.Length - $max)
}

function Do-Upload($body) {
  $code = "$($body.code)"
  if ($code.Trim().Length -eq 0) { return @{ ok = $false; stage = 'input'; log = '沒有程式碼' } }
  if ($code.Length -gt 200000) { return @{ ok = $false; stage = 'input'; log = '程式碼太長' } }
  New-Item -ItemType Directory -Force -Path $SketchDir | Out-Null
  [IO.File]::WriteAllText($SketchFile, $code, (New-Object Text.UTF8Encoding($false)))

  Write-Host ("[{0:HH:mm:ss}] 編譯中……" -f (Get-Date))
  $c = Invoke-Cli @('compile', '--fqbn', $Fqbn, $SketchDir)
  $log = $c.out + $c.err
  if ($c.code -ne 0) {
    Write-Host '  編譯失敗' -ForegroundColor Red
    return @{ ok = $false; stage = 'compile'; log = (Tail-Log $log) }
  }
  Write-Host '  編譯成功' -ForegroundColor Green
  if ($body.verifyOnly) { return @{ ok = $true; stage = 'compile'; log = (Tail-Log $log) } }

  $port = "$($body.port)"
  if ($port -notmatch '^COM\d+$') { return @{ ok = $false; stage = 'upload'; log = "連接埠不對：$port" } }
  Write-Host ("[{0:HH:mm:ss}] 燒錄到 {1}……" -f (Get-Date), $port)
  $u = Invoke-Cli @('upload', '-p', $port, '--fqbn', $Fqbn, $SketchDir) 60000
  $ulog = $u.out + $u.err
  if ($u.code -ne 0 -and $ulog -match 'not in sync|not responding|resp=0x') {
    Write-Host '  換舊版 bootloader 再試一次……'
    $u = Invoke-Cli @('compile', '-u', '-p', $port, '--fqbn', $FqbnOld, $SketchDir) 90000
    $ulog = $ulog + "`n--- 改用舊版 bootloader 重試 ---`n" + $u.out + $u.err
  }
  if ($u.code -ne 0) {
    Write-Host '  燒錄失敗' -ForegroundColor Red
    return @{ ok = $false; stage = 'upload'; log = (Tail-Log ($log + "`n" + $ulog)) }
  }
  Write-Host '  燒錄完成' -ForegroundColor Green
  return @{ ok = $true; stage = 'upload'; log = (Tail-Log ($log + "`n" + $ulog)) }
}

function Handle($ctx) {
  $req = $ctx.Request
  $origin = $req.Headers['Origin']
  if ($origin -and -not ($AllowedOrigins -contains $origin)) {
    Write-Host "拒絕來自 $origin 的要求" -ForegroundColor Yellow
    Send-Json $ctx 403 @{ ok = $false; error = '這個網站不能使用燒錄小幫手' }
    return
  }
  if ($req.HttpMethod -eq 'OPTIONS') {
    Add-Cors $ctx
    $ctx.Response.AddHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    $ctx.Response.AddHeader('Access-Control-Allow-Headers', 'Content-Type')
    $ctx.Response.AddHeader('Access-Control-Allow-Private-Network', 'true')
    $ctx.Response.AddHeader('Access-Control-Max-Age', '600')
    $ctx.Response.StatusCode = 204
    $ctx.Response.Close()
    return
  }
  $path = $req.Url.AbsolutePath
  if ($req.HttpMethod -eq 'GET' -and $path -eq '/status') {
    Send-Json $ctx 200 @{ ok = $true; version = $HelperVersion; fqbn = $Fqbn; ports = (Get-Ports) }
    return
  }
  if ($req.HttpMethod -eq 'POST' -and $path -eq '/upload') {
    $reader = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $body = $reader.ReadToEnd() | ConvertFrom-Json
    Send-Json $ctx 200 (Do-Upload $body)
    return
  }
  Send-Json $ctx 404 @{ ok = $false; error = '沒有這個功能' }
}

# ---- 啟動 ----
$host.UI.RawUI.WindowTitle = '燒錄小幫手（關掉這個視窗就停止）'
$script:Cli = Find-Cli
if (-not $script:Cli) {
  Write-Host '找不到 arduino-cli。請先安裝 Arduino IDE 2（https://www.arduino.cc/en/software）。' -ForegroundColor Red
  return
}
$cores = (Invoke-Cli @('core', 'list') 30000).out
if ($cores -notmatch 'arduino:avr') {
  Write-Host '還沒安裝 Arduino AVR 開發板套件，正在安裝（需要網路，第一次約 1～3 分鐘）……' -ForegroundColor Yellow
  Invoke-Cli @('core', 'update-index') 300000 | Out-Null
  $ins = Invoke-Cli @('core', 'install', 'arduino:avr') 600000
  if ($ins.code -ne 0) { Write-Host ('安裝失敗：' + $ins.err) -ForegroundColor Red; return }
}

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add("http://localhost:$Port/")
try { $listener.Start() } catch {
  Write-Host "無法使用連接埠 $Port（可能小幫手已經開著了）：$($_.Exception.Message)" -ForegroundColor Red
  return
}
Write-Host '======================================' -ForegroundColor Cyan
Write-Host ' 燒錄小幫手已啟動 ✓' -ForegroundColor Cyan
Write-Host " 網址：http://localhost:$Port"
Write-Host ' 回到「音符視覺化」網頁，按「🧪 寫程式燒錄」就可以上傳程式。'
Write-Host ' 用完直接關掉這個視窗。'
Write-Host '======================================' -ForegroundColor Cyan

try {
  while ($listener.IsListening) {
    $task = $listener.GetContextAsync()
    while (-not $task.AsyncWaitHandle.WaitOne(500)) { }
    $ctx = $task.Result
    try { Handle $ctx }
    catch {
      Write-Host "錯誤：$($_.Exception.Message)" -ForegroundColor Red
      try { Send-Json $ctx 500 @{ ok = $false; stage = 'helper'; log = "小幫手發生錯誤：$($_.Exception.Message)" } } catch {}
    }
  }
} finally {
  $listener.Stop()
}
